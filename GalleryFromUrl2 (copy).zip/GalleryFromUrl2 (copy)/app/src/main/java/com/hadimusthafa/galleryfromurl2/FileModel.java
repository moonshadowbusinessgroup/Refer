package com.hadimusthafa.galleryfromurl2;

public class FileModel {
    private String Url, Name, File;

    public String getUrl() {
        return Url;
    }

    public void setUrl(String url) {
        Url = url;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getFile() {
        return File;
    }

    public void setFile(String file) {
        File = file;
    }
}

