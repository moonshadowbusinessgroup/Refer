package com.hadimusthfa.prolog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class SignUp extends AppCompatActivity {

    DBHelper dbHelper;

    CardView signUp;
    EditText username, email, mobile, dob, password, rePass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        dbHelper = new DBHelper(this);

        signUp = findViewById(R.id.idSignUp);

        username = findViewById(R.id.idUsrnm);
        email = findViewById(R.id.idEml);
        mobile = findViewById(R.id.idMob);
        dob = findViewById(R.id.idDob);
        password = findViewById(R.id.idPass);
        rePass = findViewById(R.id.idRePass);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Username = username.getText().toString().trim();
                String Email = email.getText().toString().trim();
                String Mobile = mobile.getText().toString().trim();
                String Dob = dob.getText().toString().trim();
                String Password = password.getText().toString().trim();
                String Repassword = rePass.getText().toString().trim();


                if (Username.isEmpty()) {
                    username.setError("User Name cannot be empty");

                } else if (Email.isEmpty()) {
                    email.setError("Email cannot be empty");
                } else if (Mobile.isEmpty()) {
                    mobile.setError("Mobile Number cannot be empty");
                } else if (Dob.isEmpty()) {
                    dob.setError("Date of Birth cannot be empty");
                } else if (Password.isEmpty() || Repassword.isEmpty()) {
                    password.setError("Password cannot be empty");
                    rePass.setError("Password cannot be empty");
                }


                if (!Username.isEmpty() && !Email.isEmpty() && !Mobile.isEmpty() && !Dob.isEmpty() && !Password.isEmpty()) {

                    if (Password.equals(Repassword)) {
                        if (Password.length() >= 8) {
                            long val = dbHelper.addUser(Username, Email, Mobile, Dob, Password);

                            if (val > 0) {
                                Toast.makeText(SignUp.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(SignUp.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(SignUp.this, "Registration Unsuccessful", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(SignUp.this, "Password must to be 8 characters or more!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(SignUp.this, "Password is not matching", Toast.LENGTH_SHORT).show();
                    }
                }

            }

        });
    }
}
