package com.hadimusthafa.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UI8_ST_EB extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_u_i8__s_t__e_b);
    }
}